﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication2
{
    class SqrtDecomposition
    {
        public List<long> _values;
        public List<long> _sortedBlocks;
        public List<long> _blocksSums;
        public List<long> _blocksMaximum;
        public List<long> _blocksPromise;
        public int _blockCount;
        public int _blockSize;

        public SqrtDecomposition(IReadOnlyCollection<int> values)
        {
            ListsResizing();
            var size = values.Count;
            _blockSize = (int)Math.Ceiling(Math.Sqrt(size));
            _blockCount = (int)Math.Ceiling(size / (double)_blockSize);
            foreach (var t in values)
            {
                _values.Add(t);
                _sortedBlocks.Add(t);
            }

            for (var i = 0; i < _blockCount; ++i)
            {
                if (i == _blockCount - 1 && _values.Count % _blockSize != 0)
                {
                    _sortedBlocks.Sort(i * _blockSize, _values.Count % _blockSize, null);
                }
                else
                {
                    _sortedBlocks.Sort(i * _blockSize, _blockSize, null);
                }
            }
            ListsFilling();
        }


        private void ListsResizing()
        {
            _values = new List<long>();
            _sortedBlocks = new List<long>();
            _blocksSums = new List<long>();
            _blocksMaximum = new List<long>();
            _blocksPromise = new List<long>();
        }

        private void ListsFilling()
        {
            for (var i = 0; i < _values.Count; ++i)
            {
                var ind = i / _blockSize;
                if (i % _blockSize == 0)
                {
                    _blocksPromise.Add(0);
                    _blocksSums.Add(0);
                    _blocksMaximum.Add(int.MinValue);
                }
                _blocksSums[ind] += _values[i];
                _blocksMaximum[ind] = Math.Max(_blocksMaximum[ind], _values[i]);
            }
        }

        public long QueryForSumAnswer(int left, int right)
        {
            long answer = 0;
            for (var i = left - 1; i < right;)
            {
                if (i % _blockSize == 0 && i + _blockSize <= right)
                {
                    answer += _blocksSums[i / _blockSize];
                    i += _blockSize;
                }
                else
                {
                    answer += _blocksPromise[i / _blockSize] + _values[i++];
                }
            }
            return answer;
        }

        public long QueryForMaxAnswer(int left, int right)
        {
            long answer = int.MinValue;
            for (var i = left - 1; i < right;)
            {
                if (i % _blockSize == 0 && i + _blockSize <= right)
                {
                    answer = Math.Max(answer, _blocksMaximum[i / _blockSize]);
                    i += _blockSize;
                }
                else
                {
                    answer = Math.Max(answer, _blocksPromise[i / _blockSize] + _values[i++]);
                }
            }

            return answer;
        }

        private int BinarySearch(int left, int right, int value, int ind, int block)
        {
            if (left == right)
            {
                return _sortedBlocks[left] + _blocksPromise[block] <= value ? 1 : 0;
            }

            int middle = (left + right) / 2;
            if (_sortedBlocks[middle] + _blocksPromise[block] <= value)
            {
                int answer = middle - ind + 1;
                answer += BinarySearch(middle + 1, right, value, middle + 1, block);
                return answer;
            }
            else
            {
                return BinarySearch(left, middle, value, ind, block);
            }
        }

        public int QueryForCountAnswer(int left, int right, int value)
        {
            --left;
            --right;
            var answer = 0;
            for (var i = left; i < right + 1;)
            {
                if (i % _blockSize == 0 && i + _blockSize <= right + 1)
                {
                    answer += BinarySearch(i, i + _blockSize - 1, value,
                        i / _blockSize * _blockSize, i / _blockSize);
                    i += _blockSize;
                }
                else
                {
                    if (_values[i++] + _blocksPromise[(i - 1) / _blockSize] <= value)
                        ++answer;
                }
            }

            return answer;
        }

        private void BruteForceChanging(int ind, int value)
        {
            if (value < 0)
            {
                _blocksMaximum[ind] = int.MinValue;
                for (var j = 0; j < _blockSize; ++j)
                {
                    if (j + ind * _blockSize >= _values.Count)
                        break;
                    _blocksMaximum[ind] = Math.Max(_blocksMaximum[ind], _values[j + ind * _blockSize] + _blocksPromise[ind]);
                }
            }
        }

        private void SortedBlocksChanging(int ind)
        {
            for (int i = 0; i < _blockSize && i + ind * _blockSize < _values.Count; ++i)
            {
                _sortedBlocks[i + ind * _blockSize] = _values[i + ind * _blockSize];
            }

            if (ind * _blockSize + _blockSize >= _values.Count)
            {
                _sortedBlocks.Sort(ind * _blockSize, _values.Count - ind * _blockSize, null);
            }
            else
            {
                _sortedBlocks.Sort(ind * _blockSize, _blockSize, null);
            }
        }

        public void QueryElementChanging(int left, int right, int value)
        {
            if (value == 0)
                return;
            --left;
            --right;
            int firstBlock = -1, secondBlock = -1;
            var flag = false;
            for (var i = left; i < right + 1;)
            {
                var ind = i / _blockSize;
                if (i % _blockSize == 0 && (i + _blockSize <= right + 1 || ind == _blockCount - 1 && right + 1 == _values.Count))
                {
                    _blocksSums[ind] += value * _blockSize;
                    _blocksPromise[ind] += value;
                    _blocksMaximum[ind] += value;
                    i += _blockSize;
                    continue;
                }
                if (!flag)
                {
                    firstBlock = ind;
                    flag = true;
                }
                else
                    secondBlock = ind;
                _blocksSums[ind] += value;
                _values[i++] += value;
                if (value > 0)
                    _blocksMaximum[ind] = Math.Max(_blocksMaximum[ind], _values[i - 1] + _blocksPromise[ind]);
                if ((i) % _blockSize == 0 || (i - 1) == right)
                    BruteForceChanging(ind, value);
            }
            if (firstBlock != -1)
                SortedBlocksChanging(firstBlock);
            if (secondBlock != -1)
                SortedBlocksChanging(secondBlock);
        }
    }
}
