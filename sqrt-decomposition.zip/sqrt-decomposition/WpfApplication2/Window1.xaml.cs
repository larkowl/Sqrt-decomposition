﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication2
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        List<TextBox> blocks;
        int count = -1;
        ReadValues iinput;
        int start = 0;
        public Window1()
        {
            InitializeComponent();
            blocks = new List<TextBox>() { textBox1, textBox2 , textBox3 , textBox4 , textBox5 , textBox6 , textBox7 , textBox8 , textBox9 , textBox10 ,
            textBox11, textBox12, textBox13, textBox14, textBox15, textBox16, textBox17, textBox18, textBox19, textBox20};
            iinput = new ReadValues();
            for (int i = 0; i < blocks.Count; ++i)
            {
                blocks[i].Visibility = Visibility.Hidden;
                blocks[i].TextAlignment = TextAlignment.Center;
            }
        }

        private void textBox_MouseEnter(object sender, MouseEventArgs e)
        {
            (sender as TextBox).Background = Brushes.BurlyWood;
        }

        private void textBox_MouseLeave(object sender, MouseEventArgs e)
        {
            (sender as TextBox).Background = Brushes.Transparent;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                count = Convert.ToInt32(Amount.Text);
            }
            catch
            {
                Amount.BorderBrush = Brushes.Red;
                return;
            }
            if (count < 1 || count > 10000)
            {
                Amount.BorderBrush = Brushes.Red;
                return;
            }
            iinput.n = count;
            button1.Visibility = Visibility.Visible;
            ElementsBoxes();
        }

        private void ElementsBoxes()
        {
            int i = 0;
            for (; i < count && i < 20; ++i)
            {
                blocks[i].Visibility = Visibility.Visible;
                blocks[i].Text = (i + start).ToString();
            }
            start += i;
            count -= i;
            if (count == 0)
            {
                button1.Content = "Сохранить";
            }
        }

        private void Amount_KeyDown(object sender, KeyEventArgs e)
        {
            Amount.BorderBrush = Brushes.Transparent;
        }

        private void Json_Write()
        {
            string test = JsonConvert.SerializeObject(iinput);
            File.WriteAllText("Test.json", test);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            bool check = true;
            for (int i = 0; i < blocks.Count; ++i)
            {
                if (blocks[i].Visibility == Visibility.Visible)
                {
                    int value = 0;
                    try
                    {
                        value = Convert.ToInt32(blocks[i].Text);
                    }
                    catch
                    {
                        blocks[i].BorderBrush = Brushes.Red;
                        check = false;
                    }
                    if (Math.Abs(value) > 10000000)
                    {
                        blocks[i].BorderBrush = Brushes.Red;
                        check = false;
                    }
                }
            }
            if (!check) return;
            for (int i = 0; i < blocks.Count; ++i)
            {
                if (blocks[i].Visibility == Visibility.Visible)
                {
                    iinput.values.Add(Convert.ToInt32(blocks[i].Text));
                    blocks[i].Visibility = Visibility.Hidden;
                    blocks[i].BorderBrush = Brushes.Transparent;
                }
            }
            if ((string)button1.Content == "Ввести")
                ElementsBoxes();
            else
            {
                Json_Write();
                Properties.Settings.Default.newInput = true;
                start = 0;
                MainWindow w = new MainWindow();
                w.Closed += Window_Closed;
                w.Show();
                this.Hide();
            }
        }

        private void textBox_Copy3_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            input.Visibility = Visibility.Visible;
        }

        private void textBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Properties.Settings.Default.test = 1;
            MainWindow w = new MainWindow();
            w.Closed += Window_Closed;
            w.Show();
            this.Hide();
        }

        private void textBox_Copy_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Properties.Settings.Default.test = 2;
            MainWindow w = new MainWindow();
            w.Closed += Window_Closed;
            w.Show();
            this.Hide();
        }

        private void textBox_Copy1_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Properties.Settings.Default.test = 3;
            MainWindow w = new MainWindow();
            w.Closed += Window_Closed;
            w.Show();
            this.Hide();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            this.Show();
        }
    }
}
