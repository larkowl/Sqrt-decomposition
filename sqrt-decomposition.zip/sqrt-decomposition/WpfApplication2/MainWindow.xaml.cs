﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApplication2
{
    public partial class MainWindow : Window
    {
        System.Threading.Timer dispatcherTimer;
        public List<Ellipse> ellipses;
        public List<Ellipse> ellipses2;
        public List<Ellipse> ellipses3;
        public List<ArcSegment> arcs;
        public List<Label> mainArray;
        public List<Rectangle> sumsRectangles;
        public List<Rectangle> promisesRectangles;
        public List<Label> sums;
        public List<Label> sorted;
        public List<Label> promises;
        public List<Line> lines = new List<Line>();
        SqrtDecomposition dec;
        SqrtSplit split;
        private double toArcSegment = 0;
        string CurMode = "sum";
        public MainWindow()
        {
            InitializeComponent();

            mainArray = new List<Label>();
            sums = new List<Label>();
            sorted = new List<Label>();
            promises = new List<Label>();
            ellipses = new List<Ellipse>();
            ellipses2 = new List<Ellipse>();
            ellipses3 = new List<Ellipse>();
            sumsRectangles = new List<Rectangle>();
            promisesRectangles = new List<Rectangle>();
            if (Properties.Settings.Default.test == 1)
                ReadInput("first");
            else if (Properties.Settings.Default.test == 2)
                ReadInput("second");
            else if (Properties.Settings.Default.test == 3)
                ReadInput("third");
            else
                ReadInput("test");
            ColumnDefinitionsFunction();
            BlocksVisualisation();
            ConstructorVisualisation();
        }

        private void ReadInput(string file)
        {
            using (StreamReader r = new StreamReader(file + ".json"))
            {
                string json = r.ReadToEnd();
                ReadValues item = JsonConvert.DeserializeObject<ReadValues>(json);
                split = new SqrtSplit(item.values);
                dec = new SqrtDecomposition(item.values);
            }
        }

        #region Preperation
        private void ColumnDefinitionsFunction()
        {
            for (int i = 0; i < dec._blockCount; ++i)
            {
                Sums.ColumnDefinitions.Add(new ColumnDefinition());
                FirstLines.ColumnDefinitions.Add(new ColumnDefinition());
                Promises.ColumnDefinitions.Add(new ColumnDefinition());
                Func.ColumnDefinitions.Add(new ColumnDefinition());
                SecondLines.ColumnDefinitions.Add(new ColumnDefinition());
                Ranges.ColumnDefinitions.Add(new ColumnDefinition());
                if (i == dec._blockCount - 1 && dec._values.Count % dec._blockSize != 0)
                {
                    double percent = (dec._values.Count % dec._blockSize);
                    double percent2 = percent / dec._blockSize;
                    Sums.ColumnDefinitions[i].Width = new GridLength(percent2, GridUnitType.Star);
                    FirstLines.ColumnDefinitions[i].Width = new GridLength(percent2, GridUnitType.Star);
                    Promises.ColumnDefinitions[i].Width = new GridLength(percent2, GridUnitType.Star);
                    SecondLines.ColumnDefinitions[i].Width = new GridLength(percent2, GridUnitType.Star);
                    Func.ColumnDefinitions[i].Width = new GridLength(percent2, GridUnitType.Star);
                    toArcSegment += percent2;
                }
                else
                    toArcSegment++;
            }
        }
        #endregion

        #region BlocksVisualisation
        private Label Blocks(long value)
        {
            Label label = new Label()
            {
                Content = value,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                BorderBrush = Brushes.Black,
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center
            };
            return label;
        }

        private void BlocksVisualisation()
        {
            for (int i = 0; i < dec._blockCount; ++i)
            {
                int currentWidth = (int)this.Width - 20 - (int)Sums.Margin.Left - (int)Sums.Margin.Right;
                int currentHeight = (int)this.Height - 35 - (int)Sums.Margin.Bottom - (int)Sums.Margin.Top;
                double oneCurrent = currentWidth / toArcSegment;
                if (i == dec._blockCount - 1 && dec._values.Count % dec._blockSize != 0)
                    oneCurrent *= (toArcSegment - (int)toArcSegment);
                TextBox textbox = NewTextBox(i);
                AddControl(Ranges, i, textbox);
                Rectangle rec = new Rectangle()
                {
                    Height = (Height - 35) / 9.5 * 0.7,
                    Width = (Height - 35) / 9.5 * 0.7,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                };
                Rectangle rec1 = new Rectangle()
                {
                    Height = (Height - 35) / 9.5 * 0.7,
                    Width = (Height - 35) / 9.5 * 0.7,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                };
                promisesRectangles.Add(rec1);
                AddControl(Promises, i, rec1);
                sumsRectangles.Add(rec);
                AddControl(Func, i, rec);
                Label label1 = Blocks(dec._blocksPromise[i]);
                Label label2 = Blocks(dec._blocksSums[i]);
                AddControl(Promises, i, label1);
                AddControl(Func, i, label2);
                sums.Add(label2);
                promises.Add(label1);
            }
        }
        #endregion

        #region Resizing
        private System.Windows.Shapes.Path ArcsSegments(double oneCurrent, int currentHeight)
        {

            PathFigure pthFigure = new PathFigure();
            pthFigure.StartPoint = new Point(0, currentHeight);
            ArcSegment arcSeg = new ArcSegment();
            arcSeg.Point = new Point(oneCurrent, currentHeight);
            arcSeg.Size = new Size(oneCurrent / 2, currentHeight - dec._blockSize * 2);
            arcSeg.IsLargeArc = true;
            arcSeg.SweepDirection = SweepDirection.Clockwise;
            arcSeg.RotationAngle = 0;
            PathSegmentCollection myPathSegmentCollection = new PathSegmentCollection();
            myPathSegmentCollection.Add(arcSeg);
            pthFigure.Segments = myPathSegmentCollection;
            PathFigureCollection pthFigureCollection = new PathFigureCollection();
            pthFigureCollection.Add(pthFigure);
            PathGeometry pthGeometry = new PathGeometry();
            pthGeometry.Figures = pthFigureCollection;
            System.Windows.Shapes.Path arcPath = new System.Windows.Shapes.Path();
            arcPath.Stroke = new SolidColorBrush(Colors.Black);
            arcPath.StrokeThickness = 1;
            arcPath.Data = pthGeometry;
            return arcPath;
        }

        private Line LineResizing(double oneCurrent, int currentHeight)
        {
            Line line = new Line()
            {
                X1 = oneCurrent / 2.0,
                Y1 = 0,
                X2 = oneCurrent / 2.0,
                Y2 = (Height - 35) / 9.5,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            return line;
        }
        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Sums.Children.Clear();
            FirstLines.Children.Clear();
            SecondLines.Children.Clear();
            int currentWidth = (int)Central.ActualWidth - 20 - (int)Sums.Margin.Left - (int)Sums.Margin.Right;
            int currentHeight = ((int)MainGrid.ActualHeight - 35) / (int)9.5;
            textBox.Height = currentHeight * 1.1;
            textBox_Copy.Height = currentHeight * 0.7;
            textBox2.Height = currentHeight * 0.7;
            SortedTextBlock.Height = currentHeight * 1;
            double oneCurrent = currentWidth / toArcSegment;
            for (int i = 0; i < dec._blockCount; ++i)
            {
                if (i == dec._blockCount - 1 && dec._values.Count % dec._blockSize != 0)
                    oneCurrent *= (toArcSegment - (int)toArcSegment);
                Line line2 = LineResizing(oneCurrent, currentHeight);
                Line line = LineResizing(oneCurrent, currentHeight);
                System.Windows.Shapes.Path path = ArcsSegments(oneCurrent, currentHeight);
                Sums.Children.Add(path);
                FirstLines.Children.Add(line);
                SecondLines.Children.Add(line2);
                Grid.SetColumn(line2, i);
                Grid.SetColumn(line, i);
                Grid.SetColumn(path, i);
                promises[i].Height = (Height - 35) / 9.5 * 0.7;
                promises[i].Width = promises[i].Height;
                sums[i].Height = (Height - 35) / 9.5 * 0.7;
                sums[i].Width = promises[i].Height;
            }
            oneCurrent = currentWidth / toArcSegment;
            double first = oneCurrent / dec._blockSize;
            double second = first;
            if (dec._values.Count % dec._blockSize != 0)
            {
                oneCurrent *= (toArcSegment - (int)toArcSegment);
                second = oneCurrent / (dec._values.Count % dec._blockSize);
            }
            for (int i = 0; i < ellipses.Count; ++i)
            {
                int ind = i / dec._blockSize;
                if (ind == dec._blockCount - 1)
                {
                    ellipses[i].Height = second;
                    ellipses2[i].Height = second;
                }
                else
                {
                    ellipses[i].Height = first;
                    ellipses2[i].Height = first;
                }
            }
            for (int i = 0; i < ellipses3.Count; ++i)
            {
                int ind = i / dec._blockSize;
                if (ind == dec._blockCount - 1)
                    ellipses3[i].Height = second;
                else
                    ellipses3[i].Height = first;
            }
        }

        #endregion

        #region Visualisation

        #region ConstructorVisualisation

        private Ellipse Ellipses()
        {
            Ellipse ell = new Ellipse()
            {
                Stroke = Brushes.Black,
                StrokeThickness = 1,
            };
            return ell;
        }

        private Label Labels(long value)
        {
            Label label = new Label()
            {
                Content = value,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 16,
                FontWeight = FontWeights.Bold,
            };
            return label;
        }

        private void AddControl(Grid grid, int column, UIElement element)
        {
            grid.Children.Add(element);
            Grid.SetColumn(element, column);
        }

        private void ConstructorVisualisation()
        {
            int currentWidth = (int)this.Width - 20 - (int)Sums.Margin.Left - (int)Sums.Margin.Right;
            double oneCurrent = currentWidth / toArcSegment;
            double first = oneCurrent / dec._blockSize;
            double second = first;
            if (dec._values.Count % dec._blockSize != 0)
            {
                oneCurrent *= (toArcSegment - (int)toArcSegment);
                second = oneCurrent / (dec._values.Count % dec._blockSize);
            }
            for (int i = 0; i < dec._values.Count; ++i)
            {
                int ind = i / dec._blockSize;
                PartialSums.ColumnDefinitions.Add(new ColumnDefinition());
                MainArray.ColumnDefinitions.Add(new ColumnDefinition());
                ForSplit.ColumnDefinitions.Add(new ColumnDefinition());
                Sorted.ColumnDefinitions.Add(new ColumnDefinition());
                TextBox textboxone = new TextBox()
                { 
                    Text = split.partial_sums[i].ToString(),
                    Background = Brushes.Transparent,
                    FontSize = 20,
                    BorderThickness = new Thickness(0, 1, 1, 1),
                    TextAlignment = TextAlignment.Center,
                    VerticalContentAlignment = VerticalAlignment.Center,
                    BorderBrush = Brushes.Black,
                };
                if (i == 0)
                    textboxone.BorderThickness = new Thickness(1, 1, 1, 1);
                Ellipse ell = Ellipses();
                Ellipse ell1 = Ellipses();
                Ellipse ell2 = Ellipses();
                if (ind == dec._blockCount - 1) {
                    ell.Height = second;
                    ell1.Height = second;
                    ell2.Height = second;
                } else {
                    ell.Height = first;
                    ell1.Height = first;
                    ell2.Height = first;
                }
                Label label = Labels(dec._values[i]);
                Label label1 = Labels(dec._sortedBlocks[i]);
                Label label2 = Labels(split.elements[i]);
                AddControl(PartialSums, i, textboxone);
                AddControl(ForSplit, i, ell2);
                ellipses3.Add(ell2);
                AddControl(ForSplit, i, label2);
                AddControl(Sorted, i, ell1);
                ellipses2.Add(ell1);
                AddControl(Sorted, i, label1);
                sorted.Add(label1);
                AddControl(MainArray, i, ell);
                ellipses.Add(ell);
                AddControl(MainArray, i, label);
                mainArray.Add(label);
            }
        }
        #endregion

        #region QueryForSumAnswerVisualisation
        private void QueryForSumAnswerVisualisation(int left, int right)
        {
            --left; --right;
            BlurEffect(left, right, 8);
            long answer = 0;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
                AnswerText.Visibility = Visibility.Visible;
                Result.Visibility = Visibility.Visible;
            }));
            Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Запрос суммы на подотрезке"));
            Thread.Sleep(Properties.Settings.Default.Interval / 2);
            for (var i = left; i < right + 1; ++i)
            {
                if (i % dec._blockSize == 0 && (i + dec._blockSize <= right + 1 || i / dec._blockSize == dec._blockCount - 1 && right + 1 == dec._values.Count))
                {
                    answer += dec._blocksSums[i / dec._blockSize];
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Comment.Text = "Добавляем готовый результат для блока";
                        Result.Text = answer.ToString();
                        sumsRectangles[i / dec._blockSize].Fill = Brushes.Yellow;
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() => sumsRectangles[(i - 1) / dec._blockSize].Fill = Brushes.Transparent));
                    i += dec._blockSize - 1;
                }
                else
                {
                    answer += dec._blocksPromise[i / dec._blockSize] + dec._values[i];
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Comment.Text = "Добавляем элемент и \"обещание\" для него";
                        Result.Text = answer.ToString();
                        promisesRectangles[i / dec._blockSize].Fill = Brushes.Yellow;
                        ellipses[i].Fill = Brushes.Yellow;
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        promisesRectangles[(i - 1) / dec._blockSize].Fill = Brushes.Transparent;
                        ellipses[i - 1].Fill = Brushes.Transparent;
                    }));
                }
            }
            BlurEffect(left, right, 0);  
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                AnswerText.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Hidden;
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
                Result.Text = "";
                Comment.Text = "";
                leftFunc.Text = "left";
                RightFunc.Text = "right";
                ValueFunc.Text = "value";
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
            }));
        }
        #endregion

        private void BlurEffect(int left, int right, int radius)
        {
            int first_block = left / dec._blockSize;
            int second_block = right / dec._blockSize;
            for (int i = 0; i < dec._values.Count; ++i)
            {
                int ind = i / dec._blockSize;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    promises[ind].Opacity = 100;
                    sums[ind].Opacity = 100;
                    mainArray[i].Opacity = 100;
                    sorted[i].Opacity = 100;
                    if (i % dec._blockSize == 0 && (ind < first_block || ind > second_block))
                    {
                        promises[ind].Effect = new BlurEffect() { Radius = radius };
                        sums[ind].Effect = new BlurEffect() { Radius = radius };
                    }
                    if (CurMode == "sort" && ((ind < first_block || ind > second_block)))
                    {
                        sorted[i].Effect = new BlurEffect() { Radius = radius };
                    }
                    if (!(i >= left && i <= right))
                    {
                        mainArray[i].Effect = new BlurEffect() { Radius = radius };
                    }
                }));
                Thread.Sleep(5);
            }
        }

        private void OpacityChange(UIElement element, bool up)
        {
            dispatcherTimer = new System.Threading.Timer((object sender) =>
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (!up)
                        element.Opacity -= 0.3;
                    else
                        element.Opacity += 0.1;
                    if (element.Opacity <= 0 && !up || element.Opacity >= 100 && up)
                    {
                        dispatcherTimer.Change(Timeout.Infinite, 0);
                    }
                }));
            }, null, 0, 100);
        }

        #region QueryElementChangingVisualisation
        private void SortedChanged(int ind)
        {
            if (CurMode == "sort")
            {
                Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Сортируем блок с новыми значениями"));
            }
            for (int i = 0; i < dec._blockSize && i + ind * dec._blockSize < dec._values.Count; ++i)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    Label label = Labels(dec._sortedBlocks[i + ind * dec._blockSize]);
                    label.Opacity = 0;
                    AddControl(Sorted, i + ind * dec._blockSize, label);
                    OpacityChange(label, true);
                    sorted[i + ind * dec._blockSize].Content = "";
                    sorted[i + ind * dec._blockSize] = label;
                    ellipses2[i + ind * dec._blockSize].Fill = Brushes.Yellow;
                }));
                Thread.Sleep(5);
            }
            Thread.Sleep(Properties.Settings.Default.Interval);
            for (int i = 0; i < dec._blockSize && i + ind * dec._blockSize < dec._values.Count; ++i)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    ellipses2[i + ind * dec._blockSize].Fill = Brushes.Transparent;
                }));
                Thread.Sleep(5);
            }
            Dispatcher.BeginInvoke(new Action(() => Comment.Text = ""));
        }

        private void MaxRechanging(int ind)
        {
            Dispatcher.BeginInvoke(new Action(() => sumsRectangles[ind].Fill = Brushes.Yellow));
            Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Обновляем максимум в блоке"));
            dec._blocksMaximum[ind] = int.MinValue;
            for (var j = 0; j < dec._blockSize && j + ind * dec._blockSize < dec._values.Count; ++j)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    ellipses[j + ind * dec._blockSize].Fill = Brushes.Yellow;
                    mainArray[j + ind * dec._blockSize].Effect = new BlurEffect() { Radius = 0 };
                    if (dec._values[j + ind * dec._blockSize] > dec._blocksMaximum[ind])
                    {
                        dec._blocksMaximum[ind] = Math.Max(dec._blocksMaximum[ind], dec._values[j + ind * dec._blockSize]);
                        Label label2 = Labels(dec._values[j + ind * dec._blockSize]);
                        label2.Opacity = 0;
                        AddControl(Func, ind, label2);
                        OpacityChange(label2, true);
                        sums[ind].Content = "";
                        sums[ind] = label2;
                    }
                }));
                Thread.Sleep(Properties.Settings.Default.Interval);
                Dispatcher.BeginInvoke(new Action(() => ellipses[j + ind * dec._blockSize - 1].Fill = Brushes.Transparent));
            }
            Dispatcher.BeginInvoke(new Action(() => sumsRectangles[ind].Fill = Brushes.Transparent));
        }

        private void QueryElementChangingVisualisation(int left, int right, int value)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
                Comment.Text = "Запрос изменения элементов на подотрезке";
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval / 2);
            --left; --right;
            BlurEffect(left, right, 8);
            var flag = false;
            int firstBlock = -1, secondBlock = -1;
            for (int i = left; i < right + 1; ++i)
            {
                var ind = i / dec._blockSize;
                if (i % dec._blockSize == 0 && (i + dec._blockSize <= right + 1 || ind == dec._blockCount - 1 && right + 1 == dec._values.Count))
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Label label;
                        if (CurMode == "sum")
                            label = Labels(dec._blocksSums[ind]);
                        else
                            label = Labels(dec._blocksMaximum[ind]);
                        Label label2 = Labels(dec._blocksPromise[ind]);
                        label.Opacity = 0;
                        label2.Opacity = 0;
                        AddControl(Func, ind, label);
                        AddControl(Promises, ind, label2);
                        OpacityChange(label, true);
                        sums[ind].Content = "";
                        sums[ind] = label;
                        OpacityChange(label2, true);
                        promises[ind].Content = "";
                        promises[ind] = label2;
                        if (CurMode == "sum")
                            Comment.Text = "Обновляем сумму блока и массив ожиданий";
                        else if (CurMode == "max")
                            Comment.Text = "Обновляем максимум блока и массив ожиданий";
                        else
                            Comment.Text = "Обновляем массив ожиданий";
                        sumsRectangles[ind].Fill = Brushes.Yellow;
                        promisesRectangles[ind].Fill = Brushes.Yellow;
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        sumsRectangles[ind].Fill = Brushes.Transparent;
                        promisesRectangles[ind].Fill = Brushes.Transparent;
                    }));
                    i += dec._blockSize - 1;
                }
                else
                {
                    Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Обновляем элемент вручную"));
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        if (CurMode == "sum" || CurMode == "sort" || (CurMode == "max" && 
                        Convert.ToInt32(sums[ind].Content) < dec._values[i] + dec._blocksPromise[ind] && value > 0))
                        {
                            Label label2;
                            if (CurMode == "max")
                                label2 = Labels(dec._values[i] + dec._blocksPromise[ind]);
                            else
                                label2 = Labels(Convert.ToInt64(sums[ind].Content) + value);
                            label2.Opacity = 0;
                            AddControl(Func, ind, label2);
                            OpacityChange(label2, true);
                            sums[ind].Content = "";
                            sums[ind] = label2;
                            sumsRectangles[ind].Fill = Brushes.Yellow;
                        }
                        Label label = Labels(dec._values[i]);
                        label.Opacity = 0;
                        AddControl(MainArray, i, label);
                        OpacityChange(label, true);
                        mainArray[i].Content = "";
                        mainArray[i] = label;
                        ellipses[i].Fill = Brushes.Yellow;
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() => ellipses[i - 1].Fill = Brushes.Transparent));
                    Dispatcher.BeginInvoke(new Action(() => sumsRectangles[ind].Fill = Brushes.Transparent));
                    if (!flag)
                    {
                        firstBlock = ind;
                        flag = true;
                    }
                    else
                        secondBlock = ind;
                }
            }
            if (firstBlock != -1)
            {
                SortedChanged(firstBlock);
                if (CurMode == "max" && value < 0)
                {
                    MaxRechanging(firstBlock);
                }
            }
            if (secondBlock != -1 && firstBlock != secondBlock)
            {
                SortedChanged(secondBlock);
                if (CurMode == "max" && value < 0)
                    MaxRechanging(secondBlock);
            }
            BlurEffect(left, right, 0);
            Dispatcher.BeginInvoke(new Action(() => {
                Comment.Text = "";
                LeftUpdate.Text = "left";
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
                RightUpdate.Text = "right";
                ValueUpdate.Text = "value";
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
            }));
        }
        #endregion

        #region QueryMaxAnswerVisualisation
        private void QueryMaxAnswerVisualisation(int left, int right)
        {
            --left; --right;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
                AnswerText.Visibility = Visibility.Visible;
                Result.Visibility = Visibility.Visible;
                Comment.Text = "Запрос максимума на подотрезке";
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval / 2);
            long answer = int.MinValue;
            BlurEffect(left, right, 8);
            for (var i = left; i < right + 1; ++i)
            {
                if (i % dec._blockSize == 0 && (i + dec._blockSize <= right + 1 || i / dec._blockSize == dec._blockCount - 1 && right + 1 == dec._values.Count))
                {
                    Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Сравниваем с готовым максимумом на подотрезке"));
                    answer = Math.Max(answer, dec._blocksMaximum[i / dec._blockSize]);
                    Dispatcher.BeginInvoke(new Action(() => Result.Text = answer.ToString()));
                    Dispatcher.BeginInvoke(new Action(() => sumsRectangles[i / dec._blockSize].Fill = Brushes.Yellow));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() => sumsRectangles[(i - 1) / dec._blockSize].Fill = Brushes.Transparent));
                    i += dec._blockSize - 1;
                }
                else
                {
                    Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Сравниваем элементы на подотрезке вручную, учитывая \"обещания\""));
                    answer = Math.Max(answer, dec._blocksPromise[i / dec._blockSize] + dec._values[i]);
                    Dispatcher.BeginInvoke(new Action(() => Result.Text = answer.ToString()));
                    Dispatcher.BeginInvoke(new Action(() => promisesRectangles[i / dec._blockSize].Fill = Brushes.Yellow));
                    Dispatcher.BeginInvoke(new Action(() => ellipses[i].Fill = Brushes.Yellow));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() => promisesRectangles[(i - 1) / dec._blockSize].Fill = Brushes.Transparent));
                    Dispatcher.BeginInvoke(new Action(() => ellipses[i - 1].Fill = Brushes.Transparent));
                }
            }
            BlurEffect(left, right, 0);
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
                Comment.Text = " ";
                AnswerText.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Hidden;
                Result.Text = "";
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
                leftFunc.Text = "left";
                RightFunc.Text = "right";
                ValueFunc.Text = "value";
            }));
        }
        #endregion

        #region QueryForCountAnswerVisualisation
        private int BinarySearch(int left, int right, int value, int ind, int block)
        {
            int middle = (left + right) / 2;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Line line1 = new Line() { X1 = 0, Y1 = 0, X2 = 0, Y2 = ellipses2[0].Height, Height = ellipses2[0].Height, Stroke = Brushes.Red, StrokeThickness = 2 };
                Line line2 = new Line() { X1 = 0, Y1 = 0, X2 = 0, Y2 = ellipses2[0].Height, Height = ellipses2[0].Height, Stroke = Brushes.Red, StrokeThickness = 2 };
                lines.Add(line1);
                lines.Add(line2);
                Sorted.Children.Add(line1);
                Sorted.Children.Add(line2);
                Grid.SetColumn(line1, left);
                Grid.SetColumn(line2, right + 1);
                if (left != right || (left == right && dec._sortedBlocks[left] + dec._blocksPromise[block] > value))
                    Dispatcher.BeginInvoke(new Action(() => ellipses2[middle].Fill = Brushes.Yellow));
                else
                    Dispatcher.BeginInvoke(new Action(() => ellipses2[middle].Fill = Brushes.YellowGreen));
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Sorted.Children.Remove(lines[0]);
                Sorted.Children.Remove(lines[1]);
                lines.Clear();
                if (left != right || (left == right && dec._sortedBlocks[left] + dec._blocksPromise[block] > value))
                    Dispatcher.BeginInvoke(new Action(() => ellipses2[middle].Fill = Brushes.Transparent));
            }));
            if (left == right)
            {
                return dec._sortedBlocks[left] + dec._blocksPromise[block] <= value ? 1 : 0;
            }
            if (dec._sortedBlocks[middle] + dec._blocksPromise[block] <= value)
            {
                int answer = middle - ind + 1;
                for (int i = 0; i < answer; ++i)
                {
                    Dispatcher.BeginInvoke(new Action(() => ellipses2[i + ind].Fill = Brushes.YellowGreen));
                    Thread.Sleep(5);
                }
                Dispatcher.BeginInvoke(new Action(() => ellipses2[middle].Fill = Brushes.YellowGreen));
                Thread.Sleep(5);
                answer += BinarySearch(middle + 1, right, value, middle + 1, block);
                return answer;
            }
            else
            {
                return BinarySearch(left, middle, value, ind, block);
            }
        }

        private void QueryForCountAnswerVisualisation(int left, int right, int value)
        {

            --left; --right;
            var answer = 0;
            BlurEffect(left, right, 8);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
                AnswerText.Visibility = Visibility.Visible;
                Result.Visibility = Visibility.Visible;
                Comment.Text = "Запрос количества элементов на подотрезке <= value";
                Result.Text = answer.ToString();
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            for (var i = left; i < right + 1; ++i)
            {
                if (i % dec._blockSize == 0 && i + dec._blockSize <= right + 1)
                {
                    Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Бинарный поиском ищем границу по отсортированной версии блока"));
                    Dispatcher.BeginInvoke(new Action(() => promisesRectangles[i / dec._blockSize].Fill = Brushes.Yellow));
                    int res = BinarySearch(i, i + dec._blockSize - 1, value,
                        i / dec._blockSize * dec._blockSize, i / dec._blockSize);
                    Dispatcher.BeginInvoke(new Action(() => promisesRectangles[i / dec._blockSize].Fill = Brushes.Transparent));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    for (int j = 0; j < dec._blockSize; ++j)
                    {
                        Dispatcher.BeginInvoke(new Action(() => ellipses2[j + i].Fill = Brushes.Transparent));
                        Thread.Sleep(5);
                    }
                    answer += res;
                    Dispatcher.BeginInvoke(new Action(() => Result.Text = answer.ToString()));
                    i += dec._blockSize - 1;
                }
                else
                {
                    Dispatcher.BeginInvoke(new Action(() => Comment.Text = "Проверяем элементы вручную"));
                    Dispatcher.BeginInvoke(new Action(() => ellipses[i].Fill = Brushes.Yellow));
                    Dispatcher.BeginInvoke(new Action(() => promisesRectangles[i / dec._blockSize].Fill = Brushes.Yellow));
                    if (dec._values[i] + dec._blocksPromise[i / dec._blockSize] <= value)
                    {
                        ++answer;
                        Dispatcher.BeginInvoke(new Action(() => Result.Text = answer.ToString()));
                    }
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() => ellipses[i - 1].Fill = Brushes.Transparent));
                    Dispatcher.BeginInvoke(new Action(() => promisesRectangles[(i - 1) / dec._blockSize].Fill = Brushes.Transparent));
                }
            }
            BlurEffect(left, right, 0);
            Dispatcher.BeginInvoke(new Action(() => Comment.Text = ""));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
                AnswerText.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Hidden;
                Result.Text = "";
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
                leftFunc.Text = "left";
                RightFunc.Text = "right";
                ValueFunc.Text = "value";
            }));
        }
        #endregion

        #endregion



        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (CurMode == "split")
            {
                int index = 0;
                try { index = Convert.ToInt32(ValueUpdate.Text); } catch { }
                if (index < 1 || index > 10000 || index > split.elements.Count)
                {
                    ValueUpdate.BorderBrush = Brushes.Red;
                    return;
                }
                Thread thread1 = new Thread(() => EraseVisualisation(index));
                thread1.Start();
                return;
            }
            int left = -1, right = -1, value = int.MinValue + 1;
            try { left = Convert.ToInt32(LeftUpdate.Text); } catch { }
            try { right = Convert.ToInt32(RightUpdate.Text); } catch { }
            try { value = Convert.ToInt32(ValueUpdate.Text); } catch { }
            if (left < 1 || left > 10000)
                LeftUpdate.BorderBrush = Brushes.Red;
            if (right < 1 || right > 10000 || right < left || right > dec._values.Count)
                RightUpdate.BorderBrush = Brushes.Red;
            if (Math.Abs(value) > 10000000)
                ValueUpdate.BorderBrush = Brushes.Red;
            if (RightUpdate.BorderBrush == Brushes.Red || LeftUpdate.BorderBrush == Brushes.Red || ValueUpdate.BorderBrush == Brushes.Red)
                return;
            dec.QueryElementChanging(left, right, value);
            Thread thread;
            if (CurMode == "sum")
                thread = new Thread(() => QueryElementChangingVisualisation(left, right, value));
            else if (CurMode == "max")
                thread = new Thread(() => QueryElementChangingVisualisation(left, right, value));
            else
                thread = new Thread(() => QueryElementChangingVisualisation(left, right, value));
            thread.Start();
            LeftUpdate.BorderBrush = Brushes.Transparent;
            RightUpdate.BorderBrush = Brushes.Transparent;
            ValueUpdate.BorderBrush = Brushes.Transparent;
            
        }

        private void buttonRec_Click(object sender, RoutedEventArgs e)
        {
            int left = -1, right = -1, value = int.MaxValue - 1;
            try { left = Convert.ToInt32(leftFunc.Text); } catch { }
            try { right = Convert.ToInt32(RightFunc.Text); } catch { }
            if (CurMode == "sort")
            {
                try { value = Convert.ToInt32(ValueFunc.Text); } catch { }
            }
            if (left < 1 || left > 10000)
                leftFunc.BorderBrush = Brushes.Red;
            if (right < 1 || right > 10000 || right < left || right > dec._values.Count)
                RightFunc.BorderBrush = Brushes.Red;
            if (CurMode == "sort" && Math.Abs(value) > 10000000)
                ValueFunc.BorderBrush = Brushes.Red;
            if (leftFunc.BorderBrush == Brushes.Red || RightFunc.BorderBrush == Brushes.Red || ValueFunc.BorderBrush == Brushes.Red)
                return;
            Thread thread;
            if (CurMode == "split")
            {
                thread = new Thread(() => SumVisualisation(left, right));
            }
            else if (CurMode == "sum")
                thread = new Thread(() => QueryForSumAnswerVisualisation(left, right));
            else if (CurMode == "max")
                thread = new Thread(() => QueryMaxAnswerVisualisation(left, right));
            else
                thread = new Thread(() => QueryForCountAnswerVisualisation(left, right, value));
            thread.Start();
            leftFunc.BorderBrush = Brushes.Transparent;
            RightFunc.BorderBrush = Brushes.Transparent;
            ValueFunc.BorderBrush = Brushes.Transparent;
            
        }
        

        private void LeftUpdate_KeyDown(object sender, KeyEventArgs e)
        {
           (sender as TextBox).BorderBrush = Brushes.Transparent;
        }

        private void TextBox_MouseEnter(object sender, MouseEventArgs e)
        {
            (sender as TextBox).Background = Brushes.BurlyWood;
            Cursor = Cursors.Hand;
        }

        private void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            (sender as TextBox).Background = Brushes.Transparent;
            Cursor = Cursors.Arrow;
        }

        private void ChangeMode()
        {
            LeftUpdate.Text = "left";
            RightUpdate.Text = "right";
            ValueUpdate.Text = "value";
            Update.Content = "Update";
            textBox2.Visibility = Visibility.Visible;
            textBox_Copy.Visibility = Visibility.Visible;
            FirstLines.Visibility = Visibility.Visible;
            SecondLines.Visibility = Visibility.Visible;
            Func.Visibility = Visibility.Visible;
            Sorted.Visibility = Visibility.Hidden;
            Promises.Visibility = Visibility.Visible;
            Sums.Visibility = Visibility.Visible;
            Ranges.Visibility = Visibility.Hidden;
            ForSplit.Visibility = Visibility.Hidden;
            MainArray.Visibility = Visibility.Visible;
            TextBoxRanges.Visibility = Visibility.Hidden;
            PartialSums.Visibility = Visibility.Hidden;
            Requests.ColumnDefinitions[7].Width = new GridLength(0, GridUnitType.Star);
            Requests.ColumnDefinitions[2].Width = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[0].Height = new GridLength(0.7, GridUnitType.Star);
            Central.RowDefinitions[1].Height = new GridLength(0.5, GridUnitType.Star);
            Central.RowDefinitions[6].Height = new GridLength(1.2, GridUnitType.Star);
            Central.RowDefinitions[7].Height = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[5].Height = new GridLength(0, GridUnitType.Star);
        }

        private void TextBox_MouseDown(object sender, MouseButtonEventArgs e)
        {
            FuncStart.Content = "Sum";
            CurMode = "sum";
            textBox_Copy.Text = "Sums";
            ChangeMode();
            for (int i = 0; i < dec._blockCount; ++i)
                sums[i].Content = dec._blocksSums[i];
        }

        private void TextBox_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FuncStart.Content = "Max";
            textBox_Copy.Text = "Max";
            CurMode = "max";
            ChangeMode();
            for (int i = 0; i < dec._blockCount; ++i)
                sums[i].Content = dec._blocksMaximum[i];
        }

        private void TextBox_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {
            CurMode = "sort";
            Func.Visibility = Visibility.Hidden;
            Sorted.Visibility = Visibility.Visible;
            ForSplit.Visibility = Visibility.Hidden;
            MainArray.Visibility = Visibility.Visible;
            Sums.Visibility = Visibility.Visible;
            Ranges.Visibility = Visibility.Hidden;
            Promises.Visibility = Visibility.Visible;
            FirstLines.Visibility = Visibility.Visible;
            TextBoxRanges.Visibility = Visibility.Hidden;
            PartialSums.Visibility = Visibility.Hidden;
            Requests.ColumnDefinitions[2].Width = new GridLength(0, GridUnitType.Star);
            Requests.ColumnDefinitions[7].Width = new GridLength(1, GridUnitType.Star);
            Central.RowDefinitions[0].Height = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[1].Height = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[6].Height = new GridLength(1, GridUnitType.Star);
            Central.RowDefinitions[7].Height = new GridLength(1, GridUnitType.Star);
            Central.RowDefinitions[5].Height = new GridLength(0, GridUnitType.Star);
            textBox2.Text = "Promises";
            FuncStart.Content = "Search";
            LeftUpdate.Text = "left";
            RightUpdate.Text = "right";
            ValueUpdate.Text = "value";
            Update.Content = "Update";
        }

        private void TextBox_MouseLeftButtonDown_2(object sender, MouseButtonEventArgs e)
        {
            MainArray.Visibility = Visibility.Hidden;
            ForSplit.Visibility = Visibility.Visible;
            Sums.Visibility = Visibility.Hidden;
            Ranges.Visibility = Visibility.Visible;
            textBox_Copy.Visibility = Visibility.Hidden;
            FirstLines.Visibility = Visibility.Hidden;
            SecondLines.Visibility = Visibility.Hidden;
            Promises.Visibility = Visibility.Hidden;
            Func.Visibility = Visibility.Hidden;
            TextBoxRanges.Visibility = Visibility.Visible;
            PartialSums.Visibility = Visibility.Visible;
            Requests.ColumnDefinitions[2].Width = new GridLength(1, GridUnitType.Star);
            Requests.ColumnDefinitions[7].Width = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[1].Height = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[5].Height = new GridLength(0.5, GridUnitType.Star);
            Central.RowDefinitions[7].Height = new GridLength(0, GridUnitType.Star);
            Central.RowDefinitions[6].Height = new GridLength(1.2, GridUnitType.Star);
            Central.RowDefinitions[3].Height = new GridLength(0.7, GridUnitType.Star);
            textBox2.Text = "Partial sums";
            CurMode = "split";
            LeftUpdate.Text = "index";
            RightUpdate.Text = "value";
            ValueUpdate.Text = "index";
            Update.Content = "Erase";
            FuncStart.Content = "Sum";
        }

        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if ((int)slider.Value % 500 != 0)
            {
                int mode = (int)slider.Value % 500;
                if (mode < 250)
                    slider.Value -= mode;
                else
                    slider.Value += 500 - mode;
            }
            Properties.Settings.Default.Interval = (int)slider.Value;
        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            int index = 0, value = int.MaxValue - 1;
            try
            {
                index = Convert.ToInt32(LeftUpdate.Text);
                value = Convert.ToInt32(RightUpdate.Text);
            }
            catch
            { }
            if (index < 1 || index > 10000 || index > split.elements.Count)
            {
                LeftUpdate.BorderBrush = Brushes.Red;
            }
            if (Math.Abs(value) > 10000)
                RightUpdate.BorderBrush = Brushes.Red;
            if (RightUpdate.BorderBrush == Brushes.Red || LeftUpdate.BorderBrush == Brushes.Red)
                return;
            Thread thread = new Thread(() => InsertVisualisation(index, value));
            thread.Start();
        }

        private TextBox NewTextBox(int i)
        {
            TextBox textbox = new TextBox()
            {
                Text = "Start = " + (split.ranges[i].first_index + 1).ToString() + '\n'
                             + "End = " + (split.ranges[i].second_index + 1).ToString(),
                Background = Brushes.Transparent,
                FontSize = 20,
                Margin = new Thickness(5, 5, 5, 5),
                BorderThickness = new Thickness(2),
                TextAlignment = TextAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center,
                BorderBrush = Brushes.Black,
                
            };
            return textbox;
        }

        private void RebuildVisualisation()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
                Comment.Text = "Перестройка структуры";
            }));
            split.rebuild();
            Dispatcher.BeginInvoke(new Action(() =>
            {
                PartialSums.Children.Clear();
                PartialSums.ColumnDefinitions.Clear();
                for (int i = 0; i < split.elementsCount; ++i)
                {
                    PartialSums.ColumnDefinitions.Add(new ColumnDefinition());
                    TextBox textboxone = new TextBox()
                    {
                        Text = split.partial_sums[i].ToString(),
                        Background = Brushes.Transparent,
                        FontSize = 20,
                        BorderThickness = new Thickness(0, 1, 1, 1),
                        TextAlignment = TextAlignment.Center,
                        VerticalContentAlignment = VerticalAlignment.Center,
                        BorderBrush = Brushes.Black,
                    };
                    if (i == 0)
                        textboxone.BorderThickness = new Thickness(1, 1, 1, 1);
                    AddControl(PartialSums, i, textboxone);
                }
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Ranges.Children.Clear();
                Ranges.ColumnDefinitions.Clear();
                for (int i = 0; i < split.ranges.Count; ++i)
                {
                    Ranges.ColumnDefinitions.Add(new ColumnDefinition());
                    TextBox textboxone = NewTextBox(i);
                    AddControl(Ranges, i, textboxone);
                }
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                int currentWidth = (int)this.Width - 20 - (int)ForSplit.Margin.Left - (int)ForSplit.Margin.Right;
                double oneCurrent = currentWidth / split.ranges.Count;
                double first = oneCurrent / split.sqrtSize;
                ellipses3.Clear();
                ForSplit.Children.Clear();
                ForSplit.ColumnDefinitions.Clear();
                for (int i = 0; i < split.elementsCount; ++i)
                {
                    ForSplit.ColumnDefinitions.Add(new ColumnDefinition());
                    Ellipse ell = Ellipses();
                    ell.Height = first;
                    ellipses3.Add(ell);
                    Label label = Labels(split.elements[i]);
                    AddControl(ForSplit, i, ell);
                    AddControl(ForSplit, i, label);
                }
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
                Comment.Text = "";
            }));
        }

        private void SumVisualisation(int left, int right)
        {
            if (split.count == split.sqrtSize)
            {
                RebuildVisualisation();
                split.count = 0;
            }
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
                AnswerText.Visibility = Visibility.Visible;
                Result.Visibility = Visibility.Visible;
            }));
            int size = split.ranges.Count;
            left = split.Split(left - 1);
            if (size < split.ranges.Count)
                SplitVisualisation(left);
            size = split.ranges.Count;
            right = split.Split(right);
            if (size < split.ranges.Count)
                SplitVisualisation(right);
            int answer = 0;
            for (; left < right; ++left)
            {
                int start = split.ranges[left].first_index;
                int end = split.ranges[left].second_index;
                if (split.ranges[left].added)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Comment.Text = "Для недавно добавленного элемента берем значение из исходного массива";
                        (Ranges.Children[left] as TextBox).Background = Brushes.Yellow;
                        answer += split.elements[start];
                        ellipses3[start].Fill = Brushes.Yellow;
                        Result.Text = answer.ToString();
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        (Ranges.Children[left - 1] as TextBox).Background = Brushes.Transparent;
                        ellipses3[start].Fill = Brushes.Transparent;
                    }));
                }
                else
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Comment.Text = "С помощью массива префиксных сумм находим сумму для диапазона";
                        (Ranges.Children[left] as TextBox).Background = Brushes.Yellow;
                        (PartialSums.Children[end] as TextBox).Background = Brushes.Yellow;
                        if (start > 0)
                            (PartialSums.Children[start - 1] as TextBox).Background = Brushes.Yellow;
                        Result.Text = answer.ToString() + "+" + split.partial_sums[end].ToString() + (start > 0 ? ("-" + split.partial_sums[start - 1].ToString()) : "");
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval / 2);
                    answer += split.partial_sums[end] - (start > 0 ? split.partial_sums[start - 1] : 0);
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        (Ranges.Children[left] as TextBox).Background = Brushes.Transparent;
                        Result.Text = answer.ToString();
                        (PartialSums.Children[end] as TextBox).Background = Brushes.Transparent;
                        if (start > 0)
                            (PartialSums.Children[start - 1] as TextBox).Background = Brushes.Transparent;
                    }));
                    Thread.Sleep(Properties.Settings.Default.Interval);
                }
            }
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Comment.Text = "";
                AnswerText.Visibility = Visibility.Hidden;
                Result.Visibility = Visibility.Hidden;
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
                leftFunc.Text = "left";
                RightFunc.Text = "right";
                ValueFunc.Text = "value";
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
            }));
            split.count++;
        }

        private void SplitVisualisation(int j)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
                Comment.Text = "Находим диапазон, который нужно разбить";
                (Ranges.Children[j - 1] as TextBox).Background = Brushes.Yellow;
                for (int i = split.ranges[j - 1].first_index; i <= split.ranges[j - 1].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Yellow;
                for (int i = split.ranges[j].first_index; i <= split.ranges[j].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Yellow;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                for (int i = split.ranges[j - 1].first_index; i <= split.ranges[j - 1].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Transparent;
                for (int i = split.ranges[j].first_index; i <= split.ranges[j].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Transparent;
                Ranges.Children.Clear();
                Ranges.ColumnDefinitions.Clear();
                for (int i = 0; i < split.ranges.Count; ++i)
                {
                    Ranges.ColumnDefinitions.Add(new ColumnDefinition());
                    TextBox textbox = NewTextBox(i);
                    AddControl(Ranges, i, textbox);
                }
                Comment.Text = "Полученное разбиение на два диапазона";
                (Ranges.Children[j - 1] as TextBox).Background = Brushes.YellowGreen;
                (Ranges.Children[j] as TextBox).Background = Brushes.YellowGreen;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                (Ranges.Children[j - 1] as TextBox).Background = Brushes.Yellow;
                (Ranges.Children[j] as TextBox).Background = Brushes.Transparent;
                for (int i = split.ranges[j - 1].first_index; i <= split.ranges[j - 1].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Yellow;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                for (int i = split.ranges[j - 1].first_index; i <= split.ranges[j - 1].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Transparent;
                (Ranges.Children[j - 1] as TextBox).Background = Brushes.Transparent;
                (Ranges.Children[j] as TextBox).Background = Brushes.Yellow;
                for (int i = split.ranges[j].first_index; i <= split.ranges[j].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Yellow;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                (Ranges.Children[j] as TextBox).Background = Brushes.Transparent;
                for (int i = split.ranges[j].first_index; i <= split.ranges[j].second_index; ++i)
                    ellipses3[i].Fill = Brushes.Transparent;
                Comment.Text = "";
            }));
            Thread.Sleep(Properties.Settings.Default.Interval / 2);
        }

        private void EraseVisualisation(int index)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
            }));
            if (split.count == split.sqrtSize)
            {
                RebuildVisualisation();
                split.count = 0;
            }
            --index;
            int size = split.ranges.Count;
            int j = split.Split(index);
            if (size < split.ranges.Count)
                SplitVisualisation(j);
            size = split.ranges.Count;
            int ji = split.Split(index + 1);
            if (size < split.ranges.Count)
                SplitVisualisation(ji);
            split.ranges.RemoveAt(j);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
                Comment.Text = "Элемент, который нужно удалить";
                (Ranges.Children[j] as TextBox).Background = Brushes.Yellow;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Ranges.Children.Clear();
                Ranges.ColumnDefinitions.Clear();
                for (int i = 0; i < split.ranges.Count; ++i)
                {
                    Ranges.ColumnDefinitions.Add(new ColumnDefinition());
                    TextBox textbox = NewTextBox(i);
                    AddControl(Ranges, i, textbox);
                }
                Comment.Text = "Элемент удален";
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Comment.Text = "";
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
                ValueUpdate.Text = "index";
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
            }));
            split.count++;
        }

        private void InsertVisualisation(int index, int value)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Update.IsEnabled = false;
                FuncStart.IsEnabled = false;
                Insert.IsEnabled = false;
            }));
            if (split.count == split.sqrtSize)
            {
                RebuildVisualisation();
                split.count = 0;
            }
            --index;
            int size = split.ranges.Count;
            int j = split.Split(index);
            if (size < split.ranges.Count)
                SplitVisualisation(j);
            split.ranges.Insert(j, new Range(split.elementsCount, split.elementsCount, true));
            split.elements.Add(value);
            split.elementsCount++;
            split.count++;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Statuc.Text = "Visualisation is going";
                Statuc.Foreground = Brushes.Green;
                if (j > 0)
                    (Ranges.Children[j - 1] as TextBox).Background = Brushes.YellowGreen;
                (Ranges.Children[j] as TextBox).Background = Brushes.YellowGreen;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval / 2);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Ranges.Children.Clear();
                Ranges.ColumnDefinitions.Clear();
                for (int i = 0; i < split.ranges.Count; ++i)
                {
                    Ranges.ColumnDefinitions.Add(new ColumnDefinition());
                    TextBox textbox = NewTextBox(i);
                    AddControl(Ranges, i, textbox);
                }
                Ellipse ell = Ellipses();
                ell.Height = ellipses3[0].Height;
                Label label = Labels(value);
                ForSplit.ColumnDefinitions.Add(new ColumnDefinition());
                AddControl(ForSplit, split.elementsCount - 1, ell);
                AddControl(ForSplit, split.elementsCount - 1, label);
                ellipses3.Add(ell);
                if (j > 0)
                (Ranges.Children[j - 1] as TextBox).Background = Brushes.YellowGreen;
                if (j + 1 < split.ranges.Count)
                (Ranges.Children[j + 1] as TextBox).Background = Brushes.YellowGreen;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Comment.Text = "Добавление элемента";
                if (j > 0)
                    (Ranges.Children[j - 1] as TextBox).Background = Brushes.Transparent;
                (Ranges.Children[j + 1] as TextBox).Background = Brushes.Transparent;
                if (j + 1 < split.ranges.Count)
                    (Ranges.Children[j] as TextBox).Background = Brushes.Yellow;
                ellipses3[split.ranges[j].first_index].Fill = Brushes.Yellow;
            }));
            Thread.Sleep(Properties.Settings.Default.Interval);
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Comment.Text = "";
                (Ranges.Children[j] as TextBox).Background = Brushes.Transparent;
                ellipses3[split.ranges[j].first_index].Fill = Brushes.Transparent;
                Statuc.Text = "Waiting for query...";
                Statuc.Foreground = Brushes.Black;
                LeftUpdate.Text = "index";
                RightUpdate.Text = "value";
                Update.IsEnabled = true;
                FuncStart.IsEnabled = true;
                Insert.IsEnabled = true;
            }));
        }
    }
}
