﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication2
{
    [Serializable]
    class ReadValues
    {
        public int n;
        public List<int> values = new List<int>();
    }

    class Range
    {
        public int first_index;
        public int second_index;
        public bool added = false;

        public Range(int firstIndex, int secondIndex, bool added = false)
        {
            first_index = firstIndex;
            second_index = secondIndex;
            this.added = added;
        }
    }

    class SqrtSplit
    {
        public List<int> elements;
        public List<int> partial_sums;
        public List<Range> ranges;
        public int elementsCount;
        public int sqrtSize;
        public int count = 0;

        public SqrtSplit(List<int> elements)
        {
            sqrtSize = (int)Math.Ceiling(Math.Sqrt(elements.Count));
            elementsCount = elements.Count;
            partial_sums = new List<int>();
            ranges = new List<Range>();
            this.elements = new List<int>();
            for (int i = 0; i < elementsCount; ++i)
            {
                if (i % sqrtSize == 0)
                {
                    Range range = new Range(i, Math.Min(i + sqrtSize - 1, elementsCount - 1));
                    ranges.Add(range);
                }
                this.elements.Add(elements[i]);
                if (i > 0)
                    partial_sums.Add(this.elements[i] + partial_sums[i - 1]);
                else
                    partial_sums.Add(this.elements[i]);
            }
        }

        public int Split(int index)
        {
            int countS = 0;
            for (int i = 0; i < ranges.Count; ++i)
            {
                int current_count = ranges[i].second_index - ranges[i].first_index + 1;
                if (countS + current_count - 1 < index)
                {
                    countS += current_count;
                    continue;
                }

                if (countS == index)
                    return i;
                int difference = countS + current_count - index - 1;
                Range range = new Range(ranges[i].second_index - difference, ranges[i].second_index);
                ranges[i].second_index = ranges[i].second_index - difference - 1;
                ranges.Insert(i + 1, range);
                return i + 1;
            }

            return ranges.Count;
        }

        public void insert(int i, int x)
        {
            if (count == sqrtSize)
                rebuild();
            elements.Add(x);
            elementsCount++;
            int index = Split(i);
            ranges.Insert(index, new Range(elementsCount - 1, elementsCount - 1, true));
            count++;
        }

        public void erase(int i)
        {
            if (count == sqrtSize)
                rebuild();
            int index = Split(i);
            Split(i + 1);
            ranges.RemoveAt(index);
            count++;
        }

        public int Sum(int left, int right)
        {
            if (count == sqrtSize)
                rebuild();
            left = Split(left);
            right = Split(right + 1);
            int answer = 0;
            for (; left < right; ++left)
            {
                int start = ranges[left].first_index;
                int end = ranges[left].second_index;
                if (ranges[left].added)
                    answer += elements[start];
                else
                    answer += partial_sums[end] - (start > 0 ? partial_sums[start - 1] : 0);
            }

            count++;
            return answer;
        }

        public void rebuild()
        {
            count = 0;
            List<int> temp = new List<int>();
            for (int i = 0; i < ranges.Count; ++i)
            {
                for (int j = ranges[i].first_index; j < ranges[i].second_index + 1; ++j)
                {
                    temp.Add(elements[j]);
                }
            }

            ranges.Clear();
            partial_sums.Clear();
            sqrtSize = (int)Math.Ceiling(Math.Sqrt(elementsCount));
            elementsCount = temp.Count;
            elements = new List<int>();
            for (int i = 0; i < elementsCount; ++i)
            {
                elements.Add(temp[i]);
                if (i % sqrtSize == 0)
                {
                    Range range = new Range(i, Math.Min(i + sqrtSize - 1, elementsCount - 1));
                    ranges.Add(range);
                }

                if (i > 0)
                    partial_sums.Add(elements[i] + partial_sums[i - 1]);
                else
                    partial_sums.Add(elements[i]);
            }
        }
    }
}
